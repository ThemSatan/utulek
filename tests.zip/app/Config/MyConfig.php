<?php
namespace Config;

use CodeIgniter\Config\BaseConfig;

class MyConfig extends BaseConfig

{
    var$variable = 12;
}

?>