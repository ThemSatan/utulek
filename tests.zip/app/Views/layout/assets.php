<link rel="stylesheet" type="text/css" href="<?=base_url('vendor/twbs/bootstrap/dist/css/bootstrap.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?=base_url('vendor/components/font-awesome/css/all.min.css'); ?>">
<link rel="stylesheet" type="text/css" href="<?=base_url('assets/stylesheet.css'); ?>">
<link rel="stylesheet" href="https://use.typekit.net/qtn0nif.css">