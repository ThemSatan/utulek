<footer>
    <div class="col-lg-1 ">
    </div>
    <div class="col-lg-10">
        <p>
            <br>
            <a href="#" data-toggle="tooltip" style="text-align:center;" title="ThemSatan & kyom_9393" target="_blank"><i class="fa-brands fa-discord"></i></a> - 
            <a href="https://www.youtube.com/channel/UCj8TBoo3x2vikfs6EtHWeVw" data-toggle="tooltip" style="text-align:center;" title="Them Satan" target="_blank"><i class="fa-brands fa-youtube"></i></a> - 
            <a href="https://twitter.com/ThemSatan" data-toggle="tooltip" style="text-align:center;" title="@ThemSatan" target="_blank"><i class="fa-brands fa-twitter"></i></a> - 
            <a href="https://toyhou.se/ThemSatan" data-toggle="tooltip" style="text-align:center;" title="ThemSatan" target="_blank"><i class="fa-solid fa-house"></i></a> - 
            <a href="https://www.paypal.com/paypalme/themsatan" data-toggle="tooltip" style="text-align:center;" target="_blank"><i class="fa-brands fa-paypal"></i></a>
        </p>
    </div>
    <div class="col-lg-1 ">
    </div>
    <br>
</footer>